## R Script to make histogram from sequence read data
# Input is a tsv file with number of lines and fastq filename
# outputs a histogram in pdf format

main <- function() {
	
	# Take in file argument from commandline
	args <- commandArgs(trailingOnly = TRUE)
	filename <- args[1]

	# Read in data
	data <- read.table(filename)

	# Remove last line which has "total"
	data <- data[-nrow(data),]

	# Rename columns
	colnames(data) <- c("lines", "fastq")

	# Create a column called sequences based off of line number
	data$sequences <- data$lines/4

	# Print to shell
	print(data)
	  

	# Save plot to PDF format
	pdf(file = "~/Desktop/SWC/sequences/hist.pdf")
	hist(data$sequences, main = "Sample sequence totals", xlab = "reads")
	dev.off()

}

main()
