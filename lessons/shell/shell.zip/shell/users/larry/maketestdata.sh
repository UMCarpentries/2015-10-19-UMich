## Title: maketestdata.sh
# Author: Michelle Berry
# Date: 10/19/15

# loop through each fastq file and save the
# first 100 lines to a new file
for filename in *.fastq
do
	echo $filename
	head -100 $filename > ${filename}_100.txt
done

# Move shortened files into testdata directory
mkdir testdata
mv *100.txt testdata
