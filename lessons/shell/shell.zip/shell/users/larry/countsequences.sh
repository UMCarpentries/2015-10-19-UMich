## This is a simple pipeline to create a histogram of sample sequencing depth

# Print lines to file
wc -l *R1* | sort -n > sortedseqcount.txt

# Read data into R and make a histogram
Rscript plotseqdepth.R "sortedseqcount.txt" 